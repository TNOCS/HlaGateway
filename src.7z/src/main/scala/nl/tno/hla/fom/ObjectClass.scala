package nl.tno.hla.fom

import scala.xml._

case class ObjectClass(objectClass: Node) {
  lazy val name          = (objectClass \ "name").text
  lazy val sharing       = (objectClass \ "sharing").text
  lazy val semantics     = (objectClass \ "semantics").text
  lazy val attributes    = (objectClass \ "attribute") map { a => Attribute(a) } 
  lazy val objectClasses = (objectClass \ "objectClass")
    
  def getDescription(): String = { return semantics; }
  
  /**
   * Convert to a Swagger model.
   */
  def toSwaggerModel(primitiveDataTypes: Map[String, PrimitiveDataType], objectDataTypes: Map[String, ObjectDataType]): String = {
    var yaml = s"""  $name:
      |    type: object
      |    properties:
      |""".stripMargin
    attributes.foreach( attribute => {
      yaml += attribute.toSwaggerModelProperty(primitiveDataTypes, objectDataTypes, 6)
    })
    // TODO Add other object classes as reference
    return yaml
  }  
}