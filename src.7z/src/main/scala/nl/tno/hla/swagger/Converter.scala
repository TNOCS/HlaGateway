package nl.tno.hla.swagger

import scala.xml._
import nl.tno.hla.fom._

/**
 * Convert a FOM object to a Swagger definition.
 */
object Converter {
  private var referencedObjectDataTypes = scala.collection.mutable.Set[ObjectDataType]()
  private var definedObjectDataTypes = scala.collection.mutable.Set[ObjectDataType]()
  
  /**
   * Clear the converter (e.g. when creating multiple Swagger files)
   */
  def clear() {
    referencedObjectDataTypes.clear()
    definedObjectDataTypes.clear()
  }
  
  /**
   * Convert an ObjectClass to a Swagger model
   */
  def toSwaggerModel(objectClass: ObjectClass, fom: FomWrapper): String = {
    val name = objectClass.name
  
    var yaml = s"""  $name:
      |    type: object
      |    properties:
      |""".stripMargin
    objectClass.attributes.foreach( attribute => {
      yaml += attributeToModel(attribute, fom, 6)
    })
    return yaml
  }
  
  /**
   * Convert all the referenced, and not already defined ObjectDataTypes to a model.
   */
  private def objectDataTypesToModel(): String = {
    var yaml = ""
    var copy = referencedObjectDataTypes.clone()
    referencedObjectDataTypes = scala.collection.mutable.Set[ObjectDataType]()
    copy.foreach(odt => {})
    return yaml
  }
  
  /**
   * Convert an Attribute to a Swagger model
   */
  private def attributeToModel(attr: nl.tno.hla.fom.Attribute, fom: FomWrapper, numberOfSpaces: Int): String = {
    val name = attr.name
    val dataType = attr.dataType
    val desc = attr.getDescription()

    // First check if the attribute requires a model to be described
    fom.objectDataTypes get dataType match {
      case Some(dt) => {
        val spaces = " " * numberOfSpaces
        return spaces + attr.name + ":\n" + objectDataTypeToModelReference(dt, dataType, numberOfSpaces + 2)
      }
      case None => {}
    }
    
    // Second, we assume its a primitive data type (or we fail).
    fom.primitiveDataTypes get attr.dataType match {
      case Some(dt) => return primitiveDataTypeToModel(name, dt, fom, numberOfSpaces)
      case None => { 
        val error = s" *** Attribute: Error finding data type $dataType for attribute $name!\n"
        println(error)
        return ""
      }
    }     
  }
  
  private def objectDataTypeToModelReference(odt: ObjectDataType, name: String, numberOfSpaces: Int): String = {
    referencedObjectDataTypes += odt
    val spaces = " " * numberOfSpaces
    return spaces + "$ref: '#/definitions/" + name + "'\n"
  }
  
  private def primitiveDataTypeToModel(propName: String, dt: PrimitiveDataType, fom: FomWrapper, numberOfSpaces: Int): String = {
    var max = 0
    var min = 0
    var name = ""
    var desc = ""
    var dataType = ""
    var format = ""
    
    dt match {
      case b: BasicData => {
        val interpretation = b.interpretation
        name = b.name
        desc = s"$name ($interpretation)"
        dataType = name match {
          case "RPRunsignedInteger8BE"  => "integer"
          case "RPRunsignedInteger16BE" => "integer"
          case "RPRunsignedInteger32BE" => "integer"
          case "RPRunsignedInteger64BE" => "integer"
          case default => "UNKNOWN Basic data type: " + name
        }
          
        format = name match {
          case "RPRunsignedInteger8BE"  => "int32"
          case "RPRunsignedInteger16BE" => "int32"
          case "RPRunsignedInteger32BE" => "int32"
          case "RPRunsignedInteger64BE" => "int64"
          case default => "UNKNOWN Basic data type: " + name
        }
        
      }
      case s: SimpleData => {
        val semantics = s.semantics
        name = s.name
        desc = s"$name ($semantics)"
        dataType = s.representation match {
          case "HLAfloat32BE"           => "number"      
          case "HLAfloat64BE"           => "number"
          case "HLAinteger16BE"         => "integer"
          case "HLAinteger32BE"         => "integer"
          case "RPRunsignedInteger8BE"  => "integer"
          case "RPRunsignedInteger16BE" => "integer"
          case "RPRunsignedInteger32BE" => "integer"
          case "RPRunsignedInteger64BE" => "integer"
          case "HLAoctet"               => "integer"      
          case "HLAunicodeChar"         => "string"      
          case default => "UNKNOWN TYPE: " + s.representation
        }
          
        format = s.representation match {
          case "HLAfloat32BE"           => "float"      
          case "HLAfloat64BE"           => "double"
          case "HLAinteger16BE"         => "int32"
          case "HLAinteger32BE"         => "int32"
          case "RPRunsignedInteger8BE"  => "int32"
          case "RPRunsignedInteger16BE" => "int32"
          case "RPRunsignedInteger32BE" => "int32"
          case "RPRunsignedInteger64BE" => "int64"
          case "HLAoctet"               => "int32"      
          case "HLAunicodeChar"         => "string"      
          case default => "UNKNOWN TYPE: " + s.representation
        }
        
      }
      case e: EnumeratedData => {
        val fullDescription = e.fullDescription
        name = e.name
        desc = s"$name. $fullDescription"
        min = e.minimum
        max = e.maximum
        val representation = e.representation
        
        dataType = representation match {
          case "HLAfloat32BE"           => "number"      
          case "HLAfloat64BE"           => "number"
          case "HLAinteger16BE"         => "integer"
          case "HLAinteger32BE"         => "integer"
          case "RPRunsignedInteger8BE"  => "integer"
          case "RPRunsignedInteger16BE" => "integer"
          case "RPRunsignedInteger32BE" => "integer"
          case "RPRunsignedInteger64BE" => "integer"
          case "HLAoctet"               => "number"      
          case default => "UNKNOWN TYPE: " + representation
        }
          
        format = representation match {
          case "HLAfloat32BE"           => "float"      
          case "HLAfloat64BE"           => "double"
          case "HLAinteger16BE"         => "int32"
          case "HLAinteger32BE"         => "int32"
          case "RPRunsignedInteger8BE"  => "int32"
          case "RPRunsignedInteger16BE" => "int32"
          case "RPRunsignedInteger32BE" => "int32"
          case "RPRunsignedInteger64BE" => "int64"
          case "HLAoctet"               => "int32"      
          case default => "UNKNOWN TYPE: " + representation
        }
        
        if (name == "RPRboolean") {
          val spaces = " " * (numberOfSpaces-1)
          return s"""$spaces $propName:
            |$spaces   type: boolean
            |$spaces   description: $name. $fullDescription
            |""".stripMargin
        }
        
      }
    }
    
    val spaces = " " * (numberOfSpaces - 1)
    if (max > min) {
      return s"""$spaces $propName:
        |$spaces   type: $dataType
        |$spaces   format: $format
        |$spaces   minimum: $min
        |$spaces   maximum: $max
        |$spaces   description: $desc
        |""".stripMargin
    } else {
      return s"""$spaces $propName:
        |$spaces   type: $dataType
        |$spaces   format: $format
        |$spaces   description: $desc
        |""".stripMargin
    }    
  }
}